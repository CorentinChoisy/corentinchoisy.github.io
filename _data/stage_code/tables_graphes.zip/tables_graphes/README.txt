Les noms des DOSSIERS sont indiqués en majuscules
Les noms des fichiers sont indiqués en minuscules

----------------- Structure de Fichiers -----------------
|
|____ DESCRIPTIF
|   |_____ Table descrptive
|
|____UNIVARIE
    |_____ CROISE
        |_____ Tables des modèles univariés croisant les variables du donneur avec les variables du receveur et de la greffe. Les lettres majuscules à la fin des noms des fichiers indiquent les catégories de variables de la table dans l'ordre des types de croisement (ex: tab_univ_quanti_quali_DR.pdf donne la table des croisements des variables QUANTI du DONNEUR avec les variables QUALI du RECEVEUR)
    |_____ DONNEUR
        |_____ MARTINGALE
            |_____ Graphes des résidus de martingale du donneur
        |_____ PH
            |_____ schoenfeld_donneur.pdf     --- Graphes des résidus de schoenfeld du donneur
            |_____ PH_donneur.pdf             --- Courbes log-log du donneur
        |_____ MODELES
            |_____ univ_ajuste_donneur.pdf       --- Table "univariée" des variables du donneur
            |_____ modele_post_backward_donneur.pdf  --- Table du modèle complet retenu à l'issue de l'analyse univariée
    |_____ RECEVEUR
        |_____ MARTINGALE
            |_____ Graphes des résidus de martingale du receveur
        |_____ PH
            |_____ schoenfeld_receveur.pdf    ---  Graphes des résidus de schoenfeld du receveur
            |_____ PH_receveur.pdf            --- Courbes log-log du receveur
        |_____ MODELES
            |_____ univ_receveur.pdf      --- Table "univariée" des variables du receveur
            |_____ modele_post_backward_receveur.pdf       --- Table du modèle retenu à l'issue de l'étape de sélection des variables du receveur
    |_____ GREFFE
        |_____ MARTINGALE
            |_____ Graphes des résidus de martingale de la greffe
        |_____ PH
            |_____ schoenfeld_greffe.pdf      --- Graphes des résidus de schoenfeld de la greffe
            |_____ PH_greffe.pdf              --- Courbes log-log du receveur
        |_____ MODELES
            |_____ univ_ajuste_greffe.pdf        --- Table "univariée" des variables de la greffe
            |_____ model_post_backward_greffe.pdf         --- Table du modèle retenu à l'issue de l'étape de sélection des variables de la greffe

